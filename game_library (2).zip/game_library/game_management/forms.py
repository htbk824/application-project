from django import forms
from .models import Game
from django.contrib.auth.forms import UserCreationForm
from .models import UserProfile

class GameForm(forms.ModelForm):
    class Meta:
        model = Game
        fields = ['name', 'description']
        labels = {'Game'}

class RegistrationForm(UserCreationForm):
    class Meta:
        model = UserProfile
        fields = ['username', 'email', 'password1', 'password2']