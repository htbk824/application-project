from django.contrib import admin
from .models import Game
from .models import UserProfile

admin.site.register(Game)
admin.site.register(UserProfile)


# Register your models here.
